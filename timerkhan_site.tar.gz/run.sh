#!/bin/bash
cd /Users/artistm/PycharmProjects/pythonProject3
source .venv/bin/activate
python app.py 